order






public function store(Request $request)
{

$inputs = $request->all();

$months = $inputs['month'];

//Multiple insert queries
foreach ($months as $month) {
    Payments::create([
        'date'    => $input['date'],
        'year'    => $inputs['year']
        'month'   => $month,
        'amount'  => $inputs['amount'],
        'advance' => $inputs['advance'],
        'due'     => $inputs['due'],
        'record_id' => $inputs['record_id']
    ]);
}
//-------------------------------------------------//
//Batch insert, use either one
$data = [];
foreach ($months as $month) {
    $data[] = [
        'date'    => $input['date'],
        'year'    => $inputs['year']
        'month'   => $month,
        'amount'  => $inputs['amount'],
        'advance' => $inputs['advance'],
        'due'     => $inputs['due'],
        'record_id' => $inputs['record_id']
    ]
}

DB::table('payments')->insert($data);
}