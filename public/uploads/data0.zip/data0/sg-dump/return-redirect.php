->withOrder($order)->with('items', $items)->with('orderitems', $orderitems)->with('orders', $orders)

//$order = OrderItems::where('ordernumber' . '-' . 'ponumber', '=', $slug)->first();

/*         OrderItems::create([
         
         'itemnumber' => $request['itemnumber'],
         'itemqty' => $request['itemqty'],
         'freeitem' => $request['freeitem'],
         'itemprice' => $request['itemprice'],
     ]);

*/

     //$items = Item::all();
     //$orders = Order::all();
     //$orderitems = OrderItems::all();



     ->withOrder($order)->with('items', $items)