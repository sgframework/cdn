<?php

namespace cdn\Http\Controllers;

use cdn\Models\Branch;
use cdn\Models\Order;
use cdn\Models\OrderItems;
use cdn\Models\Item;

use Illuminate\Http\Request;

class GlobalController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getIndex(Request $request)
    {
        $currentuser = \Auth::user();
        $slug = OrderItems::select('slug')->where('staffid', '=', $currentuser->idnumber)->get();           
        $order = Order::where('slug', '=', $slug)->first();

        return view ('global.index')->withOrder($order)->with('slug', $slug);

    }
}
